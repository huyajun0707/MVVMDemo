package com.github.lzyzsd.jsbridge;

public interface CallBackFunction {
	
	public void onCallBack(String data);

}
