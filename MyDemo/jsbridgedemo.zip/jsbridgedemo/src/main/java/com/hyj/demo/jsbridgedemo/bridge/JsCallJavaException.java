package com.hyj.demo.jsbridgedemo.bridge;

/**
 * @author ： HuYajun <huyajun0707@gmail.com>
 * @version ： 1.0
 * @date ： 2019-10-15 17:35
 * @depiction ：
 */
public class JsCallJavaException extends Exception {
    public JsCallJavaException(String detailMessage) {
        super(detailMessage);
    }
}
