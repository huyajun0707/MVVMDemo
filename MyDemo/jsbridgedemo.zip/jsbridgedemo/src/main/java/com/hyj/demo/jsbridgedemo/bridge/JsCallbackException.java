package com.hyj.demo.jsbridgedemo.bridge;

/**
 * @author ： HuYajun <huyajun0707@gmail.com>
 * @version ： 1.0
 * @date ： 2019-10-15 17:33
 * @depiction ：
 */
public class JsCallbackException extends Exception {
    public JsCallbackException(String detailMessage) {
        super(detailMessage);
    }
}
